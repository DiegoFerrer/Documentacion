package main

func main() {
	startServer()
}
