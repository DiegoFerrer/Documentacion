require('babel-polyfill')
require('./dist/server')
