export const secret = process.env.SECRET || 'miclavesecreta'
export const mongoUrl = process.env.MONGODB_URI || 'mongodb://localhost/platzi-overflow'
export const port = process.env.PORT || 3000
