export const environment = {
  production: true,
  apiUrl: 'https://stormy-meadow-74430.herokuapp.com/api/'
};
